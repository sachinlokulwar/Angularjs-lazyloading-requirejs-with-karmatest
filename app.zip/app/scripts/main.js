'use strict';

require.config({
    baseUrl: '',
    });

require(
    [
        'scripts/app',
        'scripts/routeResolver'

    ],
    function () {
        angular.bootstrap(document, ['tqlApp']);
    });
